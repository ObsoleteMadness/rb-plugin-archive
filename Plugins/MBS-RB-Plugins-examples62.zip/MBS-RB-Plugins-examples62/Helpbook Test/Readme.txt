How to get it running?

First compile the "Helpbook Test.rb" to a bundled application.
Second open it and replace the Info.plist and place the Help folder in the Resource folder.

The info.plist file contains the three required fields.

And get Apple's Help Indexing tool to index the help files.
(it's part of the Help SDK)