Readme:

The examples are designed for RB 5.5.4 and work on all 4 platforms.
(tested on: Mac OS X 10.3.6, Mac OS 9.2, Windows XP SP2 and Linux)

Please do only use this classes if you have permission to do so.
Maybe there are still patents in your country which may limit use!


