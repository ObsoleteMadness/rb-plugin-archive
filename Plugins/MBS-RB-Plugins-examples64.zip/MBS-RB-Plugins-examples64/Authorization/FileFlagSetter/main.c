#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/errno.h>

/*
     int chmod(const char *path, mode_t mode);
*/

/*
Parameters:

1. file path
2. mode
3. user
4. group
*/

int main (int argc, const char * argv[]) {
    // insert code here...
    printf("File Flag Setter\n");

    if (argc<4)
        {
        printf("Need 4 parameters: Filepath mode user group \n");
        return 1;
        }
    
    const char* path=argv[1];
    const char* mode=argv[2];
    const char* user=argv[3];
    const char* group=argv[4];
    
    unsigned int imode=0;
    uid_t iuser=0;
    gid_t igroup=0;
    
    if (1!=sscanf(mode, "%o", &imode))
        {
        printf("mode must be an octal integer \n");
        return 2;
        }
    
    if (1!=sscanf(user, "%d", &iuser))
        {
        printf("mode must be an octal integer \n");
        return 3;
        }
    
    if (1!=sscanf(group, "%d", &igroup))
        {
        printf("mode must be an octal integer \n");
        return 4;
        }
    
    if (0!=chmod(path, imode))
        {
        printf("chmod had an error: %d \n",errno);
        return 5;
        }
        
    if (0!=chown(path, iuser, igroup))
        {
        printf("chmod had an error: %d \n",errno);
        return 6;
        }
        
    return 0;
}
