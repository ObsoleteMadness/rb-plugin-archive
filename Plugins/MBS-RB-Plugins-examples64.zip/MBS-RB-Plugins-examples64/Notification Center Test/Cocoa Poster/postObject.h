/* postObject */

#import <Cocoa/Cocoa.h>

@interface postObject : NSObject
{
}
- (IBAction)postAction:(id)sender;
@end
