#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/pwr_mgt/IOPMLib.h>
#include <stdio.h>

int main (int argc, const char * argv[]) {
    // insert code here...
    
    if (argc<2)
        {
        printf("Call with parameters. First parameter is CFAbsoluteTime value and second parameter is a string like \"wake\". \n");
        
        return -1;
        }
        else
        {
        float d;
        sscanf(argv[1], "%f", &d);
 
        CFAbsoluteTime t=d;
        CFStringRef s=CFStringCreateWithCString(0,argv[2],kCFStringEncodingASCII);
        
        CFDateRef date=CFDateCreate(nil, t);
        
        int e=IOPMSchedulePowerEvent(date, nil, s);
    
        printf("%x \n",e);
   
        return 0;
        }
}
