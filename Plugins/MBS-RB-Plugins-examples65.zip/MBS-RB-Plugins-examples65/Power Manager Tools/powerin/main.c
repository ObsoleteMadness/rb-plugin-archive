/*
 * Copyright (c) 2002 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * The contents of this file constitute Original Code as defined in and
 * are subject to the Apple Public Source License Version 1.1 (the
 * "License").  You may not use this file except in compliance with the
 * License.  Please obtain a copy of the License at
 * http://www.apple.com/publicsource and read it before using this file.
 * 
 * This Original Code and all software distributed under the License are
 * distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT.  Please see the
 * License for the specific language governing rights and limitations
 * under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */

/*
 cc -o wakein wakein.c -framework IOKit -framework CoreFoundation
*/

// usage: wakein 90
// Takes as a command line arg the number of seconds to schedule poweron in

/* Sample code to set an automatic wakeup timer to wake machines from sleep.

   When a machine is asleep, most hardware (including the processor) is
   powered off. The PMU chip is one of the few things left powered on, and it's
   able to generate a wakeup event on a timer.
   This code shows how to set the wakeup timer within the PMU.
*/

#include <stdio.h>
#include <IOKit/IOKitLib.h>
#include <CoreFoundation/CoreFoundation.h>

#define PMU_MAGIC_PASSWORD	0x0101BEEF

kern_return_t
writeDataProperty(io_object_t handle, CFStringRef name,
                  unsigned char * bytes, unsigned int size);

/* ==========================================
 * Close a device user client
 * =========================================== */
static kern_return_t
closeDevice(io_connect_t con)
{
    kern_return_t ret = IOServiceClose(con);

    if (ret != kIOReturnSuccess) {
        printf("closeDevice() error %08lx\n", (unsigned long)ret);
        return 0;
    }
    
    return ret;
}

/* ==========================================
 * Open an IORegistry device user client
 * =========================================== */
static kern_return_t
openDevice(io_object_t obj, unsigned int type, io_connect_t * con)
{
    kern_return_t ret = IOServiceOpen(obj, mach_task_self(), type, con);

    if (ret != kIOReturnSuccess) {
        printf("openDevice() error %08lx\n", (unsigned long)ret);
        return 0;
    }

    return ret;
}

/* ==========================================
 * Write a data property to the PMU driver
 * Arguments
 *     pmuReference - the IORegistry device to write to
 *     propertyName - Name of the property to write to
 *     data - Data to write
 *     dataSize - On return, has the size of the data that was written
 * =========================================== */
kern_return_t
writePMUProperty(io_object_t pmuReference, CFStringRef propertyName, void *data, size_t *dataSize)
{
    io_connect_t conObj;
    kern_return_t kr = openDevice(pmuReference, PMU_MAGIC_PASSWORD, &conObj);

    if (kr == kIOReturnSuccess) {
        kr = writeDataProperty(conObj, propertyName, (unsigned char*)data, *dataSize);
        closeDevice(conObj);
    }

    return kr;
}


/* ==========================================
 * Look through the registry and search for an
 * IONetworkInterface objects with the given
 * name.
 * If a match is found, the object is returned.
 * =========================================== */

io_object_t
getInterfaceWithName(mach_port_t masterPort, char *className)
{
     io_object_t obj;

     obj = IOServiceGetMatchingService(masterPort,
                                   IOServiceMatching( className ));

     if (obj == MACH_PORT_NULL) {
         printf("IOServiceGetMatchingService() error\n");
         return 0;
     }

     return obj;
}

/* ==========================================
 * Find the PMU in the IORegistry
 * =========================================== */
io_object_t
openPMUComPort(void)
{
    static mach_port_t masterPort;
    kern_return_t kr;
    io_object_t pmuRef;
        
    // Gets a master port to talk with the mach_kernel:
    kr = IOMasterPort(bootstrap_port, &masterPort);
    if (kr != KERN_SUCCESS) {
        printf("IOMasterPort() failed: %08lx\n", (unsigned long)kr);
        return NULL;
    }

    // Gets the interface:
    pmuRef = getInterfaceWithName(masterPort, "ApplePMU");

    // and returns the reference:
    return pmuRef;
}


/* ==========================================
 * Release our reference to the PMU in the IORegistry
 * =========================================== */
void
closePMUComPort(io_object_t pmuRef)
{
    IOObjectRelease(pmuRef);
}

/* ===========================================
 * Changes the string for a registry
 * property.
 * ===========================================  */
kern_return_t
writeDataProperty(io_object_t handle, CFStringRef name,
                  unsigned char * bytes, unsigned int size)
{
    kern_return_t               kr = kIOReturnNoMemory;
    CFDataRef                   data;
    CFMutableDictionaryRef      dict = 0;

    do {
        data = CFDataCreate( kCFAllocatorDefault, bytes, size );
        if( !data) {
            printf("CFDataCreate fails\n");
            continue;
        }
        dict = CFDictionaryCreateMutable( kCFAllocatorDefault, 1,
                                        &kCFTypeDictionaryKeyCallBacks,
                                        &kCFTypeDictionaryValueCallBacks);
        if( !dict) {
            printf("CFDictionaryCreateMutable fails\n");
            continue;
        }

        CFDictionarySetValue( dict, name, data );
        kr = IOConnectSetCFProperties( handle, dict );
        if (kr != KERN_SUCCESS)
            printf("IOConnectSetCFProperties fails\n");
    } while( false );

    if( data)
        CFRelease(data);
    if( dict)
        CFRelease(dict);

    return( kr );
}

int main (int argc, const char * argv[]) {
    int 				ret;
    size_t				dataSize;
    unsigned long			wake_time = 60;
    io_object_t				pmuReference;

    // check for wakeup time on the command line
    if(argc > 1) {
        // take the first command line argument as wakeup time
        if(argv[1])
            wake_time = atoi(argv[1]);
    }
    
    dataSize = sizeof(unsigned long);
    
    // Find PMU in IORegistry
    pmuReference = openPMUComPort();
    if(!pmuReference) {
        printf("Error: Couldn't find PMU in IORegistry. This system may not support automatic wake.\n");
        return 0;
    }
    
    // Send command to the PMU to wake the machine
    ret = writePMUProperty(pmuReference, CFSTR("AutoPower"), (unsigned long *)&wake_time, &dataSize);

    // Release reference to PMU
    closePMUComPort(pmuReference);

    return 0;
}
